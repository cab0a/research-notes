Research CAD v1.7.0 fixed STEP examples
Source: https://github.com/cab0a/research-notes
Install the matching source revision and its geometry extra.
From the extracted directory run:
python -m research_notes.revision_benchmark --corpus-dir fixtures/revision-comparison --output-dir output/check
Authored controls: LICENSE (PolyForm Noncommercial 1.0.0).
External inputs: separate upstream terms and notices in fixtures/public-step-corpus/licenses.
External self-pairs test intake only, not real manufacturer design revisions.
